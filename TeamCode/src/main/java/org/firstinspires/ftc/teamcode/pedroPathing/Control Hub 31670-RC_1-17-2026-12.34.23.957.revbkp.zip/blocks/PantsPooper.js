// IDENTIFIERS_USED=backLeftWheelDSAsDcMotor,backRightWheelDSAsDcMotor,frontLeftWheelDSAsDcMotor,frontRightWheelDSAsDcMotor,gamepad1

var backLeftPower, frontLeftPower, frontRightPower, backRightPower, myPosition, LY;

/**
 * This sample contains the bare minimum Blocks for any regular OpMode. The 3 blue
 * Comment Blocks show where to place Initialization code (runs once, after touching the
 * DS INIT button, and before touching the DS
 * Start arrow), Run code (runs once, after
 * touching Start), and Loop code (runs repeatedly
 * while the OpMode is active, namely not
 * Stopped).
 */
function runOpMode() {
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    while (linearOpMode.opModeIsActive()) {
      LY = gamepad1.getLeftStickY();
      telemetry.addNumericData('Left Stick Y', gamepad1.getLeftStickY());
      telemetry.addNumericData('Left Stick X', gamepad1.getLeftStickY());
      if (gamepad1.getLeftStickY() < 0.15 && gamepad1.getLeftStickY() > 0) {
        // Front Left Wheel
        // Forward + Backward
        frontLeftPower = 0;
      } else {
        // Front Left Wheel
        // Forward + Backward
        frontLeftPower = gamepad1.getLeftStickY();
      }
      if (gamepad1.getLeftStickY() > 0.15 && gamepad1.getLeftStickY() < 0) {
        // Front Left Wheel
        // Forward + Backward
        backLeftPower = 0;
      } else {
        // Front Left Wheel
        // Forward + Backward
        backLeftPower = gamepad1.getLeftStickY();
      }
      if (gamepad1.getLeftStickY() < -0.15 && gamepad1.getLeftStickY() > 0) {
        // Front Left Wheel
        // Forward + Backward
        frontRightPower = 0;
      } else {
        // Front Left Wheel
        // Forward + Backward
        frontRightPower = -gamepad1.getLeftStickY();
      }
      if (gamepad1.getLeftStickY() > -0.15 && gamepad1.getLeftStickY() < 0) {
        // Front Left Wheel
        // Forward + Backward
        backRightPower = 0;
      } else {
        // Front Left Wheel
        // Forward + Backward
        backRightPower = -gamepad1.getLeftStickY();
      }
      frontLeftWheelDSAsDcMotor.setPower(frontLeftPower);
      telemetry.addNumericData('key', frontLeftPower);
      telemetry.addNumericData('key', frontLeftWheelDSAsDcMotor.getPower());
      backLeftWheelDSAsDcMotor.setPower(backLeftPower);
      telemetry.addNumericData('key', backLeftPower);
      telemetry.addNumericData('key', backLeftWheelDSAsDcMotor.getPower());
      frontRightWheelDSAsDcMotor.setPower(frontRightPower);
      telemetry.addNumericData('key', frontRightPower);
      telemetry.addNumericData('key', frontRightWheelDSAsDcMotor.getPower());
      backRightWheelDSAsDcMotor.setPower(backRightPower);
      telemetry.addNumericData('key', backRightPower);
      telemetry.addNumericData('key', backRightWheelDSAsDcMotor.getPower());
      frontLeftWheelDSAsDcMotor.setPower(frontLeftPower);
      telemetry.addNumericData('key', frontLeftPower);
      telemetry.addNumericData('key', frontLeftWheelDSAsDcMotor.getPower());
      backLeftWheelDSAsDcMotor.setPower(backLeftPower);
      telemetry.addNumericData('key', backLeftPower);
      telemetry.addNumericData('key', backLeftWheelDSAsDcMotor.getPower());
      frontRightWheelDSAsDcMotor.setPower(frontRightPower);
      telemetry.addNumericData('key', frontRightPower);
      telemetry.addNumericData('key', frontRightWheelDSAsDcMotor.getPower());
      backRightWheelDSAsDcMotor.setPower(backRightPower);
      telemetry.addNumericData('key', backRightPower);
      telemetry.addNumericData('key', backRightWheelDSAsDcMotor.getPower());
      frontLeftWheelDSAsDcMotor.setPower(frontLeftPower);
      telemetry.addNumericData('key', frontLeftPower);
      telemetry.addNumericData('key', frontLeftWheelDSAsDcMotor.getPower());
      backLeftWheelDSAsDcMotor.setPower(backLeftPower);
      telemetry.addNumericData('key', backLeftPower);
      telemetry.addNumericData('key', backLeftWheelDSAsDcMotor.getPower());
      frontRightWheelDSAsDcMotor.setPower(frontRightPower);
      telemetry.addNumericData('key', frontRightPower);
      telemetry.addNumericData('key', frontRightWheelDSAsDcMotor.getPower());
      backRightWheelDSAsDcMotor.setPower(backRightPower);
      telemetry.addNumericData('key', backRightPower);
      telemetry.addNumericData('key', backRightWheelDSAsDcMotor.getPower());
      if (gamepad1.getA()) {
        frontLeftPower = 1;
        backLeftPower = 1;
        frontRightPower = 1;
        backRightPower = 1;
        frontLeftWheelDSAsDcMotor.setPower(frontLeftPower);
        backLeftWheelDSAsDcMotor.setPower(backLeftPower);
        frontRightWheelDSAsDcMotor.setPower(frontRightPower);
        backRightWheelDSAsDcMotor.setPower(backRightPower);
      }
      if (gamepad1.getB()) {
        frontLeftPower = 1;
        backLeftPower = 1;
        frontRightPower = 1;
        backRightPower = 1;
        frontLeftWheelDSAsDcMotor.setPower(-frontLeftPower);
        backLeftWheelDSAsDcMotor.setPower(-backLeftPower);
        frontRightWheelDSAsDcMotor.setPower(-frontRightPower);
        backRightWheelDSAsDcMotor.setPower(-backRightPower);
      }
      telemetry.update();
    }
  }
}
